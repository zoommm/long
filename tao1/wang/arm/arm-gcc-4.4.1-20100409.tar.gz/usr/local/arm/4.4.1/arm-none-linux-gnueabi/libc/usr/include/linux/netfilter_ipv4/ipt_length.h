#ifndef _IPT_LENGTH_H
#define _IPT_LENGTH_H

#include <linux/netfilter/xt_length.h>
#define ipt_length_info xt_length_info

#endif /*_IPT_LENGTH_H*/
